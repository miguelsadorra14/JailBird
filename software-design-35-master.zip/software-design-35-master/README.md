# Software Design 
This is the template for the team project of the Software Design course at the Vrije Universiteit Amsterdam. 
this branch is craeted to receive reviews on the code. please add your reviews in the PR
