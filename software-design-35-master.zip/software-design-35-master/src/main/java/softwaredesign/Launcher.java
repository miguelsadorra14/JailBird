package softwaredesign;

public class Launcher {

    public static void main(String[] args) {
        Main.main(args);
    }
}
